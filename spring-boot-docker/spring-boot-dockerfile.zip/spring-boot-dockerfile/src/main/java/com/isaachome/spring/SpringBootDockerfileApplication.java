package com.isaachome.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDockerfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDockerfileApplication.class, args);
	}

}
